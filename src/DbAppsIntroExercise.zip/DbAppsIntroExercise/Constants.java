package DbAppsIntroExercise;

public enum Constants {
    ;
    static final String NAME_KEY = "user";
    static final String PASS_KEY = "password";
    static final String NAME_VALUE = "root";
    static final String PASS_VALUE = "1234";
    static final String CONNECTION_URL = "jdbc:mysql://localhost:3306/minions_db";
}
