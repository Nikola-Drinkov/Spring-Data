package com.example.springdataintroexercise.enums;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
