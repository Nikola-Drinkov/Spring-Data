package com.example.springdataintroexercise.enums;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
