package com.example.springdataintroexercise.constants;

public class File_Urls {
    public static final String RESOURCES_URL = "D:\\Java Projects\\Spring Data\\SpringDataIntroExercise\\src\\main\\java\\com\\example\\springdataintroexercise\\files\\";
    public static final String AUTHORS_URL = RESOURCES_URL + "authors.txt";
    public static final String BOOKS_URL = RESOURCES_URL + "books.txt";
    public static final String CATEGORIES_URL = RESOURCES_URL + "categories.txt";
}
